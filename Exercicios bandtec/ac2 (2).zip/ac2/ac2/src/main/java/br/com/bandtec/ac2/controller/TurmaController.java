package br.com.bandtec.ac2.controller;

public class TurmaController {

}
