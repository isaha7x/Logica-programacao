insert into esporte (id, nome) values
(1, 'Ginástica'),
(2, 'Volei'),


insert into aluno (id, nome, nascimento, classe_social, bairro, turma_id) values
(1, 'Zé Ruela', '1995-01-01', 'true', 1),
(2, 'Zé Buduia', '1996-01-01', 'false', 1),
(3, 'Maria Bigodenha', '1997-01-01', 'true', 1),
(4, 'Maria Chica', '1998-01-01', 'true',  2),
(5, 'Lady Gaga', '1999-01-01', 'true', 1),
(6, 'Jojo Todinho', '2000-01-01', 'true',  2),
