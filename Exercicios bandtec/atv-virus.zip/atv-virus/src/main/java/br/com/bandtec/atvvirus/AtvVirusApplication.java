package br.com.bandtec.atvvirus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtvVirusApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtvVirusApplication.class, args);
	}

}
