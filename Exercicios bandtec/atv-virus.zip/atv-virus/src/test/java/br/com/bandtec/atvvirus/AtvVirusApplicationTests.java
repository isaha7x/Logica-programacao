package br.com.bandtec.atvvirus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtvVirusApplicationTests {

	@Test
	void contextLoads() {
	}

}
