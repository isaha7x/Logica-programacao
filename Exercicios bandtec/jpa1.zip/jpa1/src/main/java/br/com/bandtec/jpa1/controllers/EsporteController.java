package br.com.bandtec.jpa1.controllers;

import br.com.bandtec.jpa1.entidades.Esporte;
import br.com.bandtec.jpa1.repositorios.EsporteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/esportes")// sempre no plural. pois é convensão

public class EsporteController {

    @Autowired // injeta uma instancia de EsporteRepository
    private EsporteRepository repository;

    @PostMapping
    public ResponseEntity criarEsporte(@RequestBody Esporte novoEsporte){
        this.repository.save(novoEsporte);

        return  ResponseEntity.created(null).build(); // stts 201
    }

    @GetMapping
    public ResponseEntity listarTodos() {
        if (this.repository.count() >0) {
            return ResponseEntity.ok(this.repository.findAll()); // stts 200-ok
        }else{
            return ResponseEntity.noContent().build();
        }
    }

    // o findById() não retorna o objeto. Ele retorna um optuinal da classe da entidade
    //isso serve para previnir NullPointerException
    @GetMapping("/{id}")
    public  ResponseEntity  getEsporte(@PathVariable Integer id){
        Optional<Esporte> consultaEsporte = this.repository.findById(id);

        // O .isPresent() retorna true caso o valor do option não seja vazio
        //ou seja, se a consulta trouxe algo do banco
        if (consultaEsporte.isPresent()){
            // o .get() do optional tras o valor em sí (no caso um esporte)
            return ResponseEntity.ok(consultaEsporte.get());
        }else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity excluirEsporte(@PathVariable Integer id){
        if (this.repository.existsById(id)){
        this.repository.deleteById(id);
        return ResponseEntity.ok().build(); // stts 200
        }else {
            return ResponseEntity.notFound().build(); // stts 404
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity atualizaEsporte(
    @PathVariable Integer id, @RequestBody Esporte esporteAtualizado){

        Optional<Esporte> consultaExistente = this.repository.findById(id);

        if (consultaExistente.isPresent()){
        Esporte esporteEncontrado = this.repository.findById(id).get();

        esporteEncontrado.setNome(esporteAtualizado.getNome());
        esporteEncontrado.setOlimpico(esporteAtualizado.isOlimpico());

        this.repository.save(esporteEncontrado);
        return  ResponseEntity.ok().build();
        }else {
            return  ResponseEntity.notFound().build();
        }

    }
}
