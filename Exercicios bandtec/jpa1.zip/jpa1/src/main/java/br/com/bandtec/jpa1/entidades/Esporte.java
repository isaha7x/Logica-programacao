package br.com.bandtec.jpa1.entidades; // quer acessar banco de dados / converte os campos, para os tipos certo no BD

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

// Mapeamento objeto relacional (ORM - object relational Mapping)
// espelhar ou mapear tabelas em classe
// BD : Tabela, (nome)campos
//Classe : Entidade (nome)atributos
// A classe ta espelhando uma tabela do banco

//Programar o cod fonte, não vai programar o banco, pois ele já gera o banco a partir do cod
@Entity // mapeamos esta entidadee para a tabela esporte
public class Esporte {
    @Id // indica que vai ser chave primária (PK)
    @GeneratedValue // autoincremento
    private Integer id;
    private  String nome;
    private  boolean olimpico;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isOlimpico() {
        return olimpico;
    }

    public void setOlimpico(boolean olimpico) {
        this.olimpico = olimpico;
    }
}
