package br.com.bandtec.jpa1.repositorios;

import br.com.bandtec.jpa1.entidades.Esporte;
import org.springframework.data.jpa.repository.JpaRepository;
//JPARepository contém todos os métodos básicos de acesso a um BD

// repository so existe se tiver entidade

//JPA tem que saber o tipo dachave primária,por isso o integer ali dps do esporte
public interface EsporteRepository extends JpaRepository<Esporte, Integer >{

}
