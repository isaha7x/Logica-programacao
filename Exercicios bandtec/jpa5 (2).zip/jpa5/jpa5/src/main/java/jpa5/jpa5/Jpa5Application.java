package jpa5.jpa5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpa5Application {

	public static void main(String[] args) {
		SpringApplication.run(Jpa5Application.class, args);
	}

}
