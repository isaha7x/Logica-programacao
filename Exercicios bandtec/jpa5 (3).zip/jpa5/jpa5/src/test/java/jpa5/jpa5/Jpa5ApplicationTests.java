package jpa5.jpa5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jpa5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
